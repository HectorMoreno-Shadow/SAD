ls
cd /ldif
ls
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ls
nano 02-tu-turno.ldif 
ldapadd
ldapadd 02-tu-turno.ldif 
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Hector2026' "uid=hmortej,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" cn, mail
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" cn mail
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" cn mail
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)"
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" rrhh
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" rrhh
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" cn=rrhh
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" "(cn=rrhh)")
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" "(cn=rrhh)"
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" "(cn=rrhh)" member
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
exit
nano /etc/ldap/ldap.conf
exit
nano /etc/ldap/ldap.conf
exit
