mkdir -p /pki/ca && cd /pki/ca
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:4096 -out ca.key
openssl req -x509 -new -key ca.key -sha256 -days 3650   -subj "/C=ES/O=SecureCorp/CN=Hector Root CA - Hector Moreno"   -addext "basicConstraints=critical,CA:TRUE"   -addext "keyUsage=critical,keyCertSign,cRLSign"   -out ca.crt
openssl req -x509 -new -key ca.key -sha256 -days 3650   -subj "/C=ES/O=SecureCorp/CN=hmortej Root CA - Hector Moreno"   -addext "basicConstraints=critical,CA:TRUE"   -addext "keyUsage=critical,keyCertSign,cRLSign"   -out ca.crt
exit
mkdir -p /pki/servidor && cd /pki/servidor
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out ldap.key
cat > ldap.ext <<'EOF'
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = DNS:ldap.securecorp.local
EOF

ls
openssl req -new -key ldap.key -subj "/C=ES/O=SecureCorp/CN=hmortej" -out ldap.csr
openssl x509 -req -in ldap.csr -CA /pki/ca/ca.crt -CAkey /pki/ca/ca.key   -CAcreateserial -days 825 -sha256 -extfile ldap.ext -out ldap.crt
openssl verify -CAfile /pki/ca/ca.crt ldap.crt
openssl x509 -in ldap.crt -noout -subject -issuer
exit
mkdir -p /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
chown -R openldap:openldap /etc/ldap/tls
chmod 600 /etc/ldap/tls/ldap.key
ls -l /etc/ldap/tls
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
nano /ldif/03-tls.ldif
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
cat << 'EOF' > /ldif/03-tls.ldif
dn: cn=config
changetype: modify
replace: olcTLSCACertificateFile
olcTLSCACertificateFile: /etc/ldap/tls/ca.crt
-
replace: olcTLSCertificateFile
olcTLSCertificateFile: /etc/ldap/tls/ldap.crt
-
replace: olcTLSCertificateKeyFile
olcTLSCertificateKeyFile: /etc/ldap/tls/ldap.key
EOF

ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
nano /etc/default/slapd
exit
kdb5_util create -s -r SECURECORP.LOCAL     # te pide una "master key": invéntala y apúntala
service krb5-kdc start
kadmin.local -q "addprinc lromero"
kadmin.local -q "addprinc hmortej"
kadmin.local -q "addprinc mtorres"
kadmin.local -q "addprinc -randkey host/web.securecorp.local" kadmin.local -q "listprincs"
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "listprincs"
kinit hmortej
kvno host/web.securecorp.local
klist
exit
kinit lromero
exit
